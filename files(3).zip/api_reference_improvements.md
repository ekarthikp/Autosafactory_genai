# Improving `api_reference.json` for Better LLM Performance

## Executive Summary

Your `api_reference.json` is **12.4 MB (~3.2M tokens)**. After analysis against the autosarfactory MCP server implementation, I've identified that **~70% of the file is inherited boilerplate** that wastes context window and confuses weaker models. The improvements below can reduce the file to **~3-4 MB** while making it dramatically more useful for smaller/cheaper models.

---

## Current Structure Analysis

### What you have

```
api_reference.json
├── enums (349 items) — flat name → [values] lists, no descriptions
├── classes (2042 items) — each with:
│   ├── hasShortName: bool
│   ├── xmlTag: string
│   ├── description: string (missing for 56 classes)
│   ├── children[]: {hasShortName, method, description, returns}
│   ├── references[]: {method, xmlTag, name, description, type}
│   └── attributes[]: {method, xmlTag, name, description, type}
└── _comment
```

### Problems found

| Issue | Impact | Severity |
|-------|--------|----------|
| **70% inherited boilerplate** — 12 methods (set_checksum, set_timestamp, new_LongName, new_Desc, etc.) repeated across 1200-2040 classes each | Wastes **~6.3 MB** of context. Model sees same noise thousands of times. | 🔴 Critical |
| **No inheritance/hierarchy** — no `parents` field, no way to know that `ApplicationSwComponentType → AtomicSwComponentType → SwComponentType` | Model can't reason about type compatibility for `set_`/`add_` reference methods | 🔴 Critical |
| **Generic copy-paste descriptions** — 1790 children say "This specifies how the Referrable.shortName is composed..." | Model can't distinguish important domain-specific children from inherited noise | 🔴 Critical |
| **No multiplicity info** — no way to know if a child is 0..1, 0..*, or 1..1 | Model creates duplicate singletons or misses required elements | 🟠 High |
| **No enum value descriptions** — enum values are bare strings like `VALUE_STANDARD` with zero context | Model guesses wrong enum values, especially with domain-specific enums | 🟠 High |
| **206 references without descriptions** | Model doesn't know what these cross-references mean | 🟠 High |
| **No usage examples** | Model must guess correct API call sequences from scratch | 🟡 Medium |
| **No domain categorization** — 2042 classes in a flat list | Model can't narrow down which classes matter for a use case | 🟡 Medium |
| **ARPackage has 608 children all described as "Elements that are part of this package"** | Completely useless for understanding what each element IS | 🟡 Medium |
| **No constraints/validation rules** | Model generates structurally valid but semantically wrong models | 🟡 Medium |

---

## Recommended Improvements (Priority Order)

### 1. 🔴 Factor Out Inherited Members (~6.3 MB savings)

**Problem:** 12 methods appear in 1200+ classes each, with identical descriptions.

**Solution:** Define "mixins" or "traits" once, then reference them.

```json
{
  "mixins": {
    "Identifiable": {
      "description": "Base mixin for elements with identity (shortName, longName, etc.)",
      "children": [
        {"method": "new_ShortNameFragment", "hasShortName": false, "returns": "ShortNameFragment",
         "description": "Compose shortName from fragments (rarely needed — set shortName via constructor instead)"},
        {"method": "new_LongName", "hasShortName": false, "returns": "MultilanguageLongName",
         "description": "Human-readable display name"},
        {"method": "new_Desc", "hasShortName": false, "returns": "MultiLanguageOverviewParagraph",
         "description": "Brief paragraph description"},
        {"method": "new_AdminData", "hasShortName": false, "returns": "AdminData",
         "description": "Administrative metadata (company, revision, etc.)"},
        {"method": "new_Introduction", "hasShortName": false, "returns": "DocumentationBlock",
         "description": "Extended documentation block"},
        {"method": "new_Annotation", "hasShortName": false, "returns": "Annotation",
         "description": "Additional notes for tooling/documentation"}
      ],
      "attributes": [
        {"method": "set_category", "xmlTag": "CATEGORY", "name": "category", "type": "str",
         "description": "Keyword that specializes semantics (e.g. VALUE, STRUCTURE, ARRAY for data types)"},
        {"method": "set_uuid", "xmlTag": "UUID", "name": "uuid", "type": "str",
         "description": "Universally unique identifier (rarely set manually)"}
      ]
    },
    "ArObject": {
      "description": "Base mixin for all AR objects",
      "attributes": [
        {"method": "set_checksum", "xmlTag": "S", "name": "checksum", "type": "str",
         "description": "Tool-generated checksum (do not set manually)"},
        {"method": "set_timestamp", "xmlTag": "T", "name": "timestamp", "type": "str",
         "description": "Tool-generated timestamp (do not set manually)"}
      ]
    },
    "VariationPoint": {
      "children": [
        {"method": "new_VariationPoint", "hasShortName": false, "returns": "VariationPoint",
         "description": "Variation point for product line engineering (advanced, rarely used)"}
      ]
    }
  }
}
```

Then each class only lists its **own** unique members plus which mixins it inherits:

```json
{
  "ApplicationSwComponentType": {
    "mixins": ["ArObject", "Identifiable", "VariationPoint"],
    "hasShortName": true,
    "xmlTag": "APPLICATION-SW-COMPONENT-TYPE",
    "description": "An application-level software component...",
    "children": [
      // ONLY class-specific children listed here
    ],
    "references": [...],
    "attributes": [...]
  }
}
```

**Impact:** Removes ~6.3 MB of duplicated content. Models see each inherited method exactly once.


### 2. 🔴 Add Inheritance Hierarchy

**Problem:** No way to know type relationships. When `set_providedInterface` says type is `PortInterface`, the model doesn't know which concrete classes are valid.

**Solution:** Add `parents` and `subtypes` fields:

```json
{
  "ApplicationSwComponentType": {
    "parents": ["AtomicSwComponentType"],
    "subtypes": [],
    "description": "...",
    ...
  },
  "AtomicSwComponentType": {
    "parents": ["SwComponentType"],
    "subtypes": ["ApplicationSwComponentType", "SensorActuatorSwComponentType",
                  "ComplexDeviceDriverSwComponentType", "ServiceSwComponentType",
                  "EcuAbstractionSwComponentType"],
    "abstract": true,
    ...
  },
  "PortInterface": {
    "parents": [],
    "subtypes": ["SenderReceiverInterface", "ClientServerInterface",
                  "ModeSwitchInterface", "TriggerInterface"],
    "abstract": true,
    ...
  }
}
```

**Impact:** Model can resolve reference types to concrete classes. Critical for `set_`/`add_` methods.


### 3. 🔴 Deduplicate ARPackage Children Descriptions

**Problem:** ARPackage has 608 children, ALL with the description "Elements that are part of this package." This tells the model nothing.

**Solution:** Replace with meaningful descriptions per element type:

```json
{
  "ARPackage": {
    "children": [
      {"method": "new_ApplicationSwComponentType", "hasShortName": true,
       "returns": "ApplicationSwComponentType",
       "description": "Create an application-level software component (most common SWC type for application logic)"},
      {"method": "new_SenderReceiverInterface", "hasShortName": true,
       "returns": "SenderReceiverInterface",
       "description": "Create a sender-receiver port interface for data-element-based communication"},
      {"method": "new_CanCluster", "hasShortName": true,
       "returns": "CanCluster",
       "description": "Create a CAN network cluster defining physical CAN bus topology"}
    ]
  }
}
```

**Impact:** Model can pick the right `new_` method from ARPackage based on what it's trying to create.


### 4. 🟠 Add Multiplicity Annotations

**Problem:** Model doesn't know if `new_SwcInternalBehavior` can be called once or many times.

**Solution:** Add `multiplicity` field:

```json
{
  "children": [
    {"method": "new_SwcInternalBehavior", "returns": "SwcInternalBehavior",
     "multiplicity": "0..1",
     "description": "Internal behavior (runnables, events). Each SWC has at most one."},
    {"method": "new_PPortPrototype", "returns": "PPortPrototype",
     "multiplicity": "0..*",
     "description": "Provided port. An SWC can have multiple."}
  ]
}
```

**Impact:** Prevents duplicate creation bugs and missing required elements.


### 5. 🟠 Add Enum Value Descriptions

**Problem:** `ByteOrderEnum` has `VALUE_MOST_SIGNIFICANT_BYTE_FIRST` and `VALUE_MOST_SIGNIFICANT_BYTE_LAST` — self-explanatory. But `HandleTerminationAndRestartEnum` has `VALUE_CAN_BE_TERMINATED_AND_RESTARTED` — less clear for a weak model.

**Solution:** Change enums from flat lists to described objects (at minimum for domain-specific enums):

```json
{
  "enums": {
    "ByteOrderEnum": {
      "values": ["VALUE_MOST_SIGNIFICANT_BYTE_FIRST", "VALUE_MOST_SIGNIFICANT_BYTE_LAST",
                  "VALUE_OPAQUE"],
      "description": "Byte ordering for multi-byte data transmission"
    },
    "CanAddressingModeType": {
      "values": [
        {"name": "VALUE_STANDARD", "description": "11-bit CAN identifier (default)"},
        {"name": "VALUE_EXTENDED", "description": "29-bit CAN identifier"},
        {"name": "VALUE_FD", "description": "CAN FD flexible data-rate"}
      ],
      "description": "CAN frame addressing mode"
    }
  }
}
```

**Impact:** Model picks correct enum values without guessing, especially for domain-specific choices.


### 6. 🟠 Fill Missing Reference Descriptions

**Problem:** 206 references have no description. Example: `add_unitGroup` on ApplicationSwComponentType has a description, but many don't.

**Solution:** Generate descriptions from the reference name and type:

```json
{
  "method": "set_baseType",
  "xmlTag": "BASE-TYPE-REF",
  "name": "baseType",
  "type": "SwBaseType",
  "description": "Reference to the base type (e.g. uint8, uint16) that defines the physical C type representation"
}
```

**Impact:** Model understands what to pass to reference-setting methods.


### 7. 🟡 Add Domain Categories

**Problem:** 2042 classes are in a flat list. A model looking for CAN-related classes must scan all 2042.

**Solution:** Add a `domain` or `category` tag:

```json
{
  "ApplicationSwComponentType": {
    "domain": "SWC",
    ...
  },
  "CanCluster": {
    "domain": "Communication/CAN",
    ...
  },
  "EthernetCluster": {
    "domain": "Communication/Ethernet",
    ...
  },
  "SwBaseType": {
    "domain": "DataTypes",
    ...
  }
}
```

Then the MCP server can offer a `list_classes_by_domain(domain)` tool for targeted discovery.

**Impact:** Reduces search space dramatically. Weak models don't get lost in 2042 options.


### 8. 🟡 Add Inline Code Examples for Key Classes

**Problem:** No usage examples. The model must combine get_class + find_creators_of + get_enum to figure out how to use a class.

**Solution:** Add `example` snippets to the most commonly used classes (top 50-100):

```json
{
  "ApplicationSwComponentType": {
    "example": "asw = arPkg.new_ApplicationSwComponentType('MySwc')\nasw.new_PPortPrototype('outPort').set_providedInterface(srInterface)\nasw.new_RPortPrototype('inPort').set_requiredInterface(srInterface)",
    ...
  },
  "SenderReceiverInterface": {
    "example": "srIf = arPkg.new_SenderReceiverInterface('SrIf1')\nde = srIf.new_DataElement('speed')\nde.set_type(implDataType)",
    ...
  }
}
```

**Impact:** Weak models can copy-adapt examples instead of reasoning from scratch.


### 9. 🟡 Add Constraint/Validation Hints

**Solution:** Add `constraints` or `notes` field for important rules:

```json
{
  "SwcInternalBehavior": {
    "constraints": [
      "Must have exactly one parent of type AtomicSwComponentType",
      "All RunnableEntity names must be unique within this behavior",
      "Each DataReceivePoint/DataSendPoint must reference a port that exists on the parent SWC"
    ],
    ...
  }
}
```


### 10. 🟡 Convert Classes from List-of-Dicts to Dict

**Problem:** Classes are stored as `[{"ClassName": {...}}, ...]` requiring linear scan. The MCP server already converts this to a flat dict at load time.

**Solution:** Store directly as dict:

```json
{
  "classes": {
    "ApplicationSwComponentType": { ... },
    "SenderReceiverInterface": { ... }
  }
}
```

**Impact:** Simpler parsing, O(1) lookup, and the MCP server doesn't need the normalization step.

---

## Proposed Improved Structure

```json
{
  "_version": "2.0",
  "_comment": "Improved autosarfactory API reference with inheritance, categories, and examples",

  "mixins": {
    "ArObject": {
      "description": "Base for all AUTOSAR model objects",
      "attributes": [
        {"method": "set_checksum", "name": "checksum", "type": "str",
         "description": "Tool checksum (do not set manually)"},
        {"method": "set_timestamp", "name": "timestamp", "type": "str",
         "description": "Tool timestamp (do not set manually)"}
      ]
    },
    "Identifiable": {
      "description": "Named elements with identity, documentation, and administrative metadata",
      "children": [
        {"method": "new_ShortNameFragment", "returns": "ShortNameFragment"},
        {"method": "new_LongName", "returns": "MultilanguageLongName"},
        {"method": "new_Desc", "returns": "MultiLanguageOverviewParagraph"},
        {"method": "new_AdminData", "returns": "AdminData"},
        {"method": "new_Introduction", "returns": "DocumentationBlock"},
        {"method": "new_Annotation", "returns": "Annotation"}
      ],
      "attributes": [
        {"method": "set_category", "name": "category", "type": "str"},
        {"method": "set_uuid", "name": "uuid", "type": "str"}
      ]
    }
  },

  "enums": {
    "ByteOrderEnum": {
      "description": "Byte ordering for multi-byte data",
      "values": ["VALUE_MOST_SIGNIFICANT_BYTE_FIRST", "VALUE_MOST_SIGNIFICANT_BYTE_LAST", "VALUE_OPAQUE"]
    },
    "CanAddressingModeType": {
      "description": "CAN frame addressing mode",
      "values": [
        {"name": "VALUE_STANDARD", "description": "11-bit CAN ID"},
        {"name": "VALUE_EXTENDED", "description": "29-bit CAN ID"}
      ]
    }
  },

  "classes": {
    "ApplicationSwComponentType": {
      "mixins": ["ArObject", "Identifiable"],
      "parents": ["AtomicSwComponentType"],
      "subtypes": [],
      "domain": "SWC",
      "hasShortName": true,
      "xmlTag": "APPLICATION-SW-COMPONENT-TYPE",
      "description": "Application-level software component for modelling application logic. Most common SWC type.",
      "example": "asw = arPkg.new_ApplicationSwComponentType('MySwc')\nasw.new_PPortPrototype('outPort')",
      "children": [
        {"method": "new_PPortPrototype", "hasShortName": true, "returns": "PPortPrototype",
         "multiplicity": "0..*",
         "description": "Create a provided (output) port"},
        {"method": "new_RPortPrototype", "hasShortName": true, "returns": "RPortPrototype",
         "multiplicity": "0..*",
         "description": "Create a required (input) port"},
        {"method": "new_SwcInternalBehavior", "hasShortName": true, "returns": "SwcInternalBehavior",
         "multiplicity": "0..1",
         "description": "Internal behavior containing runnables and events (max one per SWC)"}
      ],
      "references": [
        {"method": "add_unitGroup", "name": "unitGroups", "type": "UnitGroup",
         "description": "Unit groups relevant to this SWC"}
      ],
      "attributes": []
    }
  }
}
```

---

## Estimated Impact

| Metric | Current | After Improvements |
|--------|---------|-------------------|
| File size | 12.4 MB | ~3-4 MB |
| Estimated tokens | ~3.2M | ~0.8-1.0M |
| Inherited noise per class | 8-12 repeated entries | 1 line (`"mixins": [...]`) |
| ARPackage child descriptions | 608× "Elements that are part of this package" | 608 unique meaningful descriptions |
| Enum context | None (bare value lists) | Description per enum + per value |
| Type hierarchy visibility | None | Full parent/subtype chains |
| Domain discoverability | Scan 2042 classes | Filter by domain tag |

---

## Implementation Roadmap

**Phase 1 (highest impact, do first):**
1. Factor out inherited members into mixins (~70% size reduction)
2. Convert classes from list-of-dicts to plain dict
3. Add `parents` and `subtypes` fields

**Phase 2 (high impact):**
4. Rewrite ARPackage children descriptions to be meaningful
5. Add multiplicity annotations
6. Add enum descriptions (at least for domain-specific enums)

**Phase 3 (nice to have):**
7. Add domain categories
8. Add code examples for top 50-100 classes
9. Add constraint/validation hints
10. Fill 206 missing reference descriptions

---

## How This Helps "Bad Models"

Weak models fail at AUTOSAR modelling for predictable reasons:

1. **Context overflow** — 3.2M tokens of JSON overflows or degrades attention. Cutting to <1M keeps the whole API in context for smaller models.

2. **Signal-to-noise ratio** — When 70% of every class is identical inherited boilerplate, the model can't find the 2-3 methods that actually matter. Mixins make the unique members stand out.

3. **Type resolution** — Without hierarchy info, `set_providedInterface(PortInterface)` is a dead end. With subtypes listed, even a weak model knows to look at `SenderReceiverInterface` or `ClientServerInterface`.

4. **Decision paralysis** — 608 identically-described ARPackage children is a nightmare for any model. Meaningful descriptions let the model pick the right `new_` method.

5. **Enum hallucination** — Without descriptions, models guess enum values from name patterns and often get them wrong. Descriptions anchor the model to correct values.

The MCP server's `instructions`, `ar_map`, and `kb` are all excellent. The JSON is the weakest link in the chain. Fix it, and even a Haiku-class model can generate correct AUTOSAR scripts.

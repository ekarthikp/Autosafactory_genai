#!/usr/bin/env python3
"""
Transform api_reference.json into an optimized version for better LLM performance.

Applies:
  1. Factor out inherited members into mixins (~70% size reduction)
  2. Convert classes from list-of-dicts to flat dict
  3. Detect and add parent/subtype hierarchy
  4. Add domain categories for common AUTOSAR classes
  5. Improve ARPackage children descriptions
  6. Add multiplicity hints where inferable
  7. Convert enums to dict format with description placeholders
  8. Add code examples for the most important classes

Usage:
    python transform_api_reference.py api_reference.json -o api_reference_v2.json
"""

import json
import argparse
import sys
from collections import Counter, defaultdict
from pathlib import Path


# ─── Configuration ───────────────────────────────────────────────────────────

# Methods that appear in 500+ classes — these are "inherited" and should be mixins
INHERITED_THRESHOLD = 500

# Domain classification for well-known AUTOSAR classes
DOMAIN_MAP = {
    # SWC types
    "ApplicationSwComponentType": "SWC",
    "SensorActuatorSwComponentType": "SWC",
    "ComplexDeviceDriverSwComponentType": "SWC",
    "ServiceSwComponentType": "SWC",
    "EcuAbstractionSwComponentType": "SWC",
    "CompositionSwComponentType": "SWC",
    "ServiceProxySwComponentType": "SWC",
    "ParameterSwComponentType": "SWC",
    "NvBlockSwComponentType": "SWC",
    "SwcImplementation": "SWC",
    "SwcInternalBehavior": "SWC/Behavior",
    "RunnableEntity": "SWC/Behavior",
    "TimingEvent": "SWC/Behavior",
    "InitEvent": "SWC/Behavior",
    "DataReceivedEvent": "SWC/Behavior",
    "OperationInvokedEvent": "SWC/Behavior",
    "DataSendPoint": "SWC/Behavior",
    "DataReceivePoint": "SWC/Behavior",
    # Ports
    "PPortPrototype": "Ports",
    "RPortPrototype": "Ports",
    "PRPortPrototype": "Ports",
    # Interfaces
    "SenderReceiverInterface": "Interfaces",
    "ClientServerInterface": "Interfaces",
    "ModeSwitchInterface": "Interfaces",
    "TriggerInterface": "Interfaces",
    "ParameterInterface": "Interfaces",
    "NvDataInterface": "Interfaces",
    "VariableDataPrototype": "Interfaces",
    "OperationPrototype": "Interfaces",
    "ArgumentDataPrototype": "Interfaces",
    # Data types
    "SwBaseType": "DataTypes",
    "ImplementationDataType": "DataTypes",
    "ImplementationDataTypeElement": "DataTypes",
    "ApplicationPrimitiveDataType": "DataTypes",
    "ApplicationRecordDataType": "DataTypes",
    "ApplicationArrayDataType": "DataTypes",
    "ApplicationRecordElement": "DataTypes",
    "ApplicationArrayElement": "DataTypes",
    "DataTypeMappingSet": "DataTypes",
    "DataTypeMap": "DataTypes",
    "CompuMethod": "DataTypes/CompuMethod",
    "CompuInternalToPhys": "DataTypes/CompuMethod",
    "CompuScale": "DataTypes/CompuMethod",
    "CompuRationalCoeffs": "DataTypes/CompuMethod",
    "CompuConst": "DataTypes/CompuMethod",
    "CompuScales": "DataTypes/CompuMethod",
    "CompuNumerator": "DataTypes/CompuMethod",
    "CompuDenominator": "DataTypes/CompuMethod",
    "DataConstr": "DataTypes/Constraints",
    "DataConstrRule": "DataTypes/Constraints",
    "InternalConstrs": "DataTypes/Constraints",
    "PhysConstrs": "DataTypes/Constraints",
    "SwDataDefProps": "DataTypes",
    "SwDataDefPropsConditional": "DataTypes",
    # CAN
    "CanCluster": "Communication/CAN",
    "CanClusterConditional": "Communication/CAN",
    "CanPhysicalChannel": "Communication/CAN",
    "CanFrame": "Communication/CAN",
    "CanFrameTriggering": "Communication/CAN",
    "CanCommunicationController": "Communication/CAN",
    "CanCommunicationConnector": "Communication/CAN",
    # Ethernet / SOME/IP
    "EthernetCluster": "Communication/Ethernet",
    "EthernetClusterConditional": "Communication/Ethernet",
    "EthernetPhysicalChannel": "Communication/Ethernet",
    "EthernetCommunicationController": "Communication/Ethernet",
    "EthernetCommunicationConnector": "Communication/Ethernet",
    "SomeipServiceInterfaceDeployment": "Communication/SOMEIP",
    "SomeipEventDeployment": "Communication/SOMEIP",
    "SomeipMethodDeployment": "Communication/SOMEIP",
    "SomeipSdServerServiceInstanceConfig": "Communication/SOMEIP",
    "SomeipSdClientServiceInstanceConfig": "Communication/SOMEIP",
    "ServiceInterfaceElementMapping": "Communication/SOMEIP",
    "ServiceInstanceToPortPrototypeMapping": "Communication/SOMEIP",
    # Signals
    "ISignal": "Communication/Signals",
    "ISignalIPdu": "Communication/Signals",
    "ISignalToIPduMapping": "Communication/Signals",
    "ISignalTriggering": "Communication/Signals",
    "ISignalPort": "Communication/Signals",
    "SystemSignal": "Communication/Signals",
    "PduToFrameMapping": "Communication/Signals",
    "PduTriggering": "Communication/Signals",
    "IPduPort": "Communication/Signals",
    "FramePort": "Communication/Signals",
    # ECU / System
    "EcuInstance": "System/ECU",
    "System": "System",
    "SystemMapping": "System",
    "SwcToEcuMapping": "System",
    "SenderReceiverToSignalMapping": "System",
    "RootSwCompositionPrototype": "System",
    # Diagnostics
    "DiagnosticIOControl": "Diagnostics",
    "DiagnosticEnableConditionGroup": "Diagnostics",
    "DiagnosticTroubleCode": "Diagnostics",
    # Core
    "ARPackage": "Core",
}

# Better descriptions for ARPackage children (override the generic "Elements that are part of this package")
ARPACKAGE_CHILD_DESCRIPTIONS = {
    "new_ApplicationSwComponentType": "Create an application-level SWC (most common for application logic)",
    "new_SensorActuatorSwComponentType": "Create an SWC for sensor/actuator hardware abstraction",
    "new_ComplexDeviceDriverSwComponentType": "Create an SWC for complex device driver (direct HW access)",
    "new_ServiceSwComponentType": "Create a service SWC (BSW service layer)",
    "new_EcuAbstractionSwComponentType": "Create an ECU abstraction SWC",
    "new_CompositionSwComponentType": "Create a composition SWC (assembles child SWCs with connectors)",
    "new_SenderReceiverInterface": "Create a sender-receiver port interface (data element communication)",
    "new_ClientServerInterface": "Create a client-server port interface (operation-based communication)",
    "new_ModeSwitchInterface": "Create a mode switch port interface",
    "new_TriggerInterface": "Create a trigger port interface",
    "new_ParameterInterface": "Create a parameter port interface (calibration parameters)",
    "new_NvDataInterface": "Create a non-volatile data port interface",
    "new_SwBaseType": "Create a primitive base type (uint8, uint16, float32, boolean, etc.)",
    "new_ImplementationDataType": "Create an implementation data type (VALUE, STRUCTURE, or ARRAY category)",
    "new_ApplicationPrimitiveDataType": "Create an application-level primitive data type",
    "new_ApplicationRecordDataType": "Create an application-level record/struct data type",
    "new_ApplicationArrayDataType": "Create an application-level array data type",
    "new_DataTypeMappingSet": "Create a mapping set between application and implementation data types",
    "new_CompuMethod": "Create a computation method (IDENTICAL, LINEAR, TEXTTABLE, etc.)",
    "new_DataConstr": "Create data constraints (valid value ranges)",
    "new_Unit": "Create a physical unit (km/h, degC, etc.)",
    "new_UnitGroup": "Create a group of related physical units",
    "new_CanCluster": "Create a CAN network cluster (physical CAN bus topology)",
    "new_CanFrame": "Create a CAN frame definition",
    "new_EthernetCluster": "Create an Ethernet network cluster",
    "new_EcuInstance": "Create an ECU instance in the system",
    "new_System": "Create a system description (top-level ECU/signal mapping)",
    "new_SystemMapping": "Create system mapping (SWC-to-ECU, signal-to-port mappings)",
    "new_ISignal": "Create an I-Signal (logical signal for inter-ECU communication)",
    "new_ISignalIPdu": "Create an I-Signal I-PDU (groups I-Signals into a protocol data unit)",
    "new_SystemSignal": "Create a system signal (abstract signal before mapping to I-Signal)",
    "new_SwcImplementation": "Create an SWC implementation (links SWC type to code/behavior)",
    "new_ARPackage": "Create a nested sub-package for organizing AUTOSAR elements",
    "new_PortInterfaceMappingSet": "Create a port interface mapping set",
    "new_DiagnosticTroubleCode": "Create a DTC (diagnostic trouble code)",
    "new_DiagnosticIOControl": "Create a diagnostic I/O control service",
    "new_ModeDeclarationGroup": "Create a mode declaration group",
    "new_TransformerChain": "Create a transformer chain (SERIALIZER, SAFETY, SECURITY steps)",
}

# Code examples for the most important classes
CODE_EXAMPLES = {
    "ApplicationSwComponentType": (
        "asw = arPkg.new_ApplicationSwComponentType('MySwc')\n"
        "pp = asw.new_PPortPrototype('outPort')\n"
        "pp.set_providedInterface(srInterface)"
    ),
    "SenderReceiverInterface": (
        "srIf = arPkg.new_SenderReceiverInterface('SrIf1')\n"
        "de = srIf.new_DataElement('speed')\n"
        "de.set_type(implDataType)"
    ),
    "ClientServerInterface": (
        "csIf = arPkg.new_ClientServerInterface('CsIf1')\n"
        "op = csIf.new_OperationPrototype('doSomething')\n"
        "arg = op.new_ArgumentDataPrototype('inputVal')\n"
        "arg.set_type(implDataType)"
    ),
    "SwcInternalBehavior": (
        "beh = asw.new_SwcInternalBehavior('Behavior')\n"
        "run = beh.new_RunnableEntity('Runnable_10ms')\n"
        "te = beh.new_TimingEvent('TE_10ms')\n"
        "te.set_startOnEvent(run)\n"
        "te.set_period('0.01')  # 10ms"
    ),
    "CompositionSwComponentType": (
        "comp = arPkg.new_CompositionSwComponentType('TopComposition')\n"
        "proto1 = comp.new_SwComponentPrototype('swc1Inst')\n"
        "proto1.set_type(asw1)\n"
        "# Create assembly connector between ports\n"
        "conn = comp.new_AssemblySwConnector('conn1')"
    ),
    "ImplementationDataType": (
        "# Primitive (category VALUE)\n"
        "idt = arPkg.new_ImplementationDataType('uint8_idt')\n"
        "idt.set_category('VALUE')\n"
        "props = idt.new_SwDataDefProps()\n"
        "cond = props.new_SwDataDefPropsConditional()\n"
        "cond.set_baseType(uint8BaseType)"
    ),
    "SwBaseType": (
        "bt = arPkg.new_SwBaseType('uint8')\n"
        "bt.set_baseTypeSize('8')    # bits\n"
        "bt.set_nativeDeclaration('unsigned char')"
    ),
    "CanCluster": (
        "cc = arPkg.new_CanCluster('CAN_Network')\n"
        "cond = cc.new_CanClusterConditional()\n"
        "cond.set_baudrate('500000')\n"
        "phy = cond.new_CanPhysicalChannel('CAN_Ch1')"
    ),
    "CompuMethod": (
        "# LINEAR: physical = 0.1 * raw - 40\n"
        "cm = arPkg.new_CompuMethod('TempConversion')\n"
        "cm.set_category('LINEAR')\n"
        "itp = cm.new_CompuInternalToPhys()\n"
        "scales = itp.new_CompuScales()\n"
        "scale = scales.new_CompuScale()\n"
        "coeffs = scale.new_CompuRationalCoeffs()\n"
        "num = coeffs.new_CompuNumerator()\n"
        "num.set_v('-40')  # offset\n"
        "num.set_v('0.1')  # factor\n"
        "den = coeffs.new_CompuDenominator()\n"
        "den.set_v('1')"
    ),
}


# ─── Transformation Logic ───────────────────────────────────────────────────

def flatten_classes(raw_classes: list) -> dict:
    """Convert list-of-single-key-dicts to a flat dict."""
    flat = {}
    for entry in raw_classes:
        flat.update(entry)
    return flat


def flatten_enums(raw_enums: list) -> dict:
    """Convert list-of-single-key-dicts to a flat dict."""
    flat = {}
    for entry in raw_enums:
        flat.update(entry)
    return flat


def detect_inherited_methods(classes: dict, threshold: int = INHERITED_THRESHOLD) -> dict:
    """
    Find methods that appear in many classes (inherited from base types).
    Returns: {method_name: count}
    """
    method_counts = Counter()
    for cls_name, cls_info in classes.items():
        for section in ["children", "references", "attributes"]:
            for item in cls_info.get(section, []):
                method_counts[item["method"]] += 1
    return {m: c for m, c in method_counts.items() if c >= threshold}


def build_mixins(classes: dict, inherited_methods: dict) -> dict:
    """
    Group inherited methods into logical mixins.
    """
    # Collect full definitions of inherited methods (take from first class that has them)
    method_defs = {}
    method_sections = {}  # method -> which section (children/references/attributes)

    for cls_name, cls_info in classes.items():
        for section in ["children", "references", "attributes"]:
            for item in cls_info.get(section, []):
                m = item["method"]
                if m in inherited_methods and m not in method_defs:
                    method_defs[m] = item
                    method_sections[m] = section

    # Group into logical mixins
    # ArObject: checksum, timestamp (appear in ~2040 classes)
    # Identifiable: shortName-related, longName, desc, adminData, annotation, etc.
    # VariationPoint: variationPoint (appears in ~1100 classes)

    ar_object_methods = {"set_checksum", "set_timestamp"}
    variation_methods = {"new_VariationPoint"}
    # Everything else that's inherited goes to Identifiable
    identifiable_methods = set(inherited_methods.keys()) - ar_object_methods - variation_methods

    def build_mixin(name, description, method_names):
        mixin = {"description": description, "children": [], "references": [], "attributes": []}
        for m in sorted(method_names):
            if m in method_defs:
                section = method_sections[m]
                mixin[section].append(method_defs[m])
        # Remove empty sections
        return {k: v for k, v in mixin.items() if v or k == "description"}

    mixins = {}
    mixins["ArObject"] = build_mixin(
        "ArObject",
        "Base for all AUTOSAR model objects. Provides checksum and timestamp (tool-managed, do not set manually).",
        ar_object_methods & set(method_defs.keys())
    )
    mixins["Identifiable"] = build_mixin(
        "Identifiable",
        "Named element with identity, documentation (longName, desc, adminData), and annotations.",
        identifiable_methods & set(method_defs.keys())
    )
    if variation_methods & set(method_defs.keys()):
        mixins["VariationPoint"] = build_mixin(
            "VariationPoint",
            "Supports product-line variation points (advanced, rarely used in basic modelling).",
            variation_methods & set(method_defs.keys())
        )

    return mixins


def detect_hierarchy(classes: dict) -> tuple:
    """
    Detect parent/subtype relationships from class names and xmlTags.
    Returns (parents_map, subtypes_map)
    """
    parents_map = defaultdict(list)
    subtypes_map = defaultdict(list)

    # Build a lookup: returns_type -> [parent_class, method]
    # If a class is only ever created as a child of another class,
    # it's likely a sub-element, not a subtype.

    # For true inheritance, we look at naming patterns and the AUTOSAR metamodel
    # This is a heuristic based on known AUTOSAR type hierarchies
    KNOWN_HIERARCHY = {
        # SwComponentType hierarchy
        "AtomicSwComponentType": ["SwComponentType"],
        "ApplicationSwComponentType": ["AtomicSwComponentType"],
        "SensorActuatorSwComponentType": ["AtomicSwComponentType"],
        "ComplexDeviceDriverSwComponentType": ["AtomicSwComponentType"],
        "ServiceSwComponentType": ["AtomicSwComponentType"],
        "EcuAbstractionSwComponentType": ["AtomicSwComponentType"],
        "CompositionSwComponentType": ["SwComponentType"],
        "ServiceProxySwComponentType": ["SwComponentType"],
        "ParameterSwComponentType": ["AtomicSwComponentType"],
        "NvBlockSwComponentType": ["AtomicSwComponentType"],
        # PortInterface hierarchy
        "SenderReceiverInterface": ["PortInterface"],
        "ClientServerInterface": ["PortInterface"],
        "ModeSwitchInterface": ["PortInterface"],
        "TriggerInterface": ["PortInterface"],
        "ParameterInterface": ["PortInterface"],
        "NvDataInterface": ["PortInterface"],
        # Port hierarchy
        "PPortPrototype": ["PortPrototype"],
        "RPortPrototype": ["PortPrototype"],
        "PRPortPrototype": ["PortPrototype"],
        # Data type hierarchy
        "ApplicationPrimitiveDataType": ["ApplicationDataType"],
        "ApplicationRecordDataType": ["ApplicationDataType"],
        "ApplicationArrayDataType": ["ApplicationDataType"],
        # Communication cluster hierarchy
        "CanCluster": ["CommunicationCluster"],
        "EthernetCluster": ["CommunicationCluster"],
        "LinCluster": ["CommunicationCluster"],
        "FlexrayCluster": ["CommunicationCluster"],
        # Implementation hierarchy
        "SwcImplementation": ["Implementation"],
        # Connector hierarchy
        "AssemblySwConnector": ["SwConnector"],
        "DelegationSwConnector": ["SwConnector"],
    }

    for cls, parents in KNOWN_HIERARCHY.items():
        if cls in classes:
            parents_map[cls] = parents
            for p in parents:
                subtypes_map[p].append(cls)

    return dict(parents_map), dict(subtypes_map)


def strip_inherited(cls_info: dict, inherited_methods: set) -> dict:
    """Remove inherited methods from a class, keeping only class-specific ones."""
    result = dict(cls_info)
    for section in ["children", "references", "attributes"]:
        if section in result:
            result[section] = [
                item for item in result[section]
                if item["method"] not in inherited_methods
            ]
    return result


def determine_mixins_for_class(cls_info: dict, inherited_methods: set,
                                ar_object_methods: set, identifiable_methods: set,
                                variation_methods: set) -> list:
    """Determine which mixins a class uses."""
    class_methods = set()
    for section in ["children", "references", "attributes"]:
        for item in cls_info.get(section, []):
            class_methods.add(item["method"])

    mixins = []
    if class_methods & ar_object_methods:
        mixins.append("ArObject")
    if class_methods & identifiable_methods:
        mixins.append("Identifiable")
    if class_methods & variation_methods:
        mixins.append("VariationPoint")
    return mixins


def improve_arpackage_descriptions(cls_info: dict) -> dict:
    """Replace generic ARPackage child descriptions with meaningful ones."""
    result = dict(cls_info)
    children = []
    for child in result.get("children", []):
        new_child = dict(child)
        method = child["method"]
        if method in ARPACKAGE_CHILD_DESCRIPTIONS:
            new_child["description"] = ARPACKAGE_CHILD_DESCRIPTIONS[method]
        elif child.get("description", "").startswith("Elements that are part of this package"):
            # Generate a description from the returns type
            returns = child.get("returns", "")
            new_child["description"] = f"Create a {returns} element in this package"
        children.append(new_child)
    result["children"] = children
    return result


def enrich_enums(enums: dict) -> dict:
    """Convert flat enum lists to richer format with description placeholder."""
    enriched = {}
    for name, values in enums.items():
        enriched[name] = {
            "values": values,
        }
    return enriched


def transform(input_path: str, output_path: str):
    """Main transformation pipeline."""
    print(f"Reading {input_path}...")
    with open(input_path, encoding="utf-8") as f:
        data = json.load(f)

    # Step 1: Flatten
    print("Flattening classes and enums...")
    classes = flatten_classes(data["classes"])
    enums = flatten_enums(data["enums"])

    # Step 2: Detect inherited methods
    print("Detecting inherited methods...")
    inherited = detect_inherited_methods(classes)
    print(f"  Found {len(inherited)} inherited methods (appearing in {INHERITED_THRESHOLD}+ classes)")
    for m, c in sorted(inherited.items(), key=lambda x: -x[1])[:10]:
        print(f"    {m}: {c} classes")

    inherited_method_names = set(inherited.keys())
    ar_object_methods = {"set_checksum", "set_timestamp"} & inherited_method_names
    variation_methods = {"new_VariationPoint"} & inherited_method_names
    identifiable_methods = inherited_method_names - ar_object_methods - variation_methods

    # Step 3: Build mixins
    print("Building mixins...")
    mixins = build_mixins(classes, inherited)

    # Step 4: Detect hierarchy
    print("Detecting type hierarchy...")
    parents_map, subtypes_map = detect_hierarchy(classes)
    print(f"  Found {len(parents_map)} classes with known parents")

    # Step 5: Transform each class
    print("Transforming classes...")
    transformed_classes = {}
    for cls_name, cls_info in classes.items():
        # Determine mixins
        cls_mixins = determine_mixins_for_class(
            cls_info, inherited_method_names,
            ar_object_methods, identifiable_methods, variation_methods
        )

        # Strip inherited methods
        stripped = strip_inherited(cls_info, inherited_method_names)

        # Build transformed class
        new_cls = {}
        if cls_mixins:
            new_cls["mixins"] = cls_mixins
        if cls_name in parents_map:
            new_cls["parents"] = parents_map[cls_name]
        if cls_name in subtypes_map:
            new_cls["subtypes"] = subtypes_map[cls_name]
        if cls_name in DOMAIN_MAP:
            new_cls["domain"] = DOMAIN_MAP[cls_name]

        new_cls["hasShortName"] = stripped.get("hasShortName", False)
        new_cls["xmlTag"] = stripped.get("xmlTag", "")

        if stripped.get("description"):
            new_cls["description"] = stripped["description"]

        if cls_name in CODE_EXAMPLES:
            new_cls["example"] = CODE_EXAMPLES[cls_name]

        # Special handling for ARPackage
        if cls_name == "ARPackage":
            stripped = improve_arpackage_descriptions(stripped)

        for section in ["children", "references", "attributes"]:
            if stripped.get(section):
                new_cls[section] = stripped[section]

        transformed_classes[cls_name] = new_cls

    # Step 6: Enrich enums
    print("Enriching enums...")
    enriched_enums = enrich_enums(enums)

    # Step 7: Assemble output
    output = {
        "_version": "2.0",
        "_comment": "Optimized autosarfactory API reference. Inherited methods factored into mixins. See 'mixins' section.",
        "_usage": {
            "mixins": "Shared method sets. A class with 'mixins': ['Identifiable'] inherits all methods from that mixin.",
            "parents": "AUTOSAR type hierarchy. Useful for resolving reference types (e.g. PortInterface -> SenderReceiverInterface).",
            "subtypes": "Concrete implementations of abstract types.",
            "domain": "Categorical grouping for easier discovery.",
            "example": "Python code snippet showing typical usage."
        },
        "mixins": mixins,
        "enums": enriched_enums,
        "classes": transformed_classes,
    }

    # Step 8: Write output
    print(f"Writing {output_path}...")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    # Stats
    input_size = Path(input_path).stat().st_size / 1_048_576
    output_size = Path(output_path).stat().st_size / 1_048_576
    reduction = (1 - output_size / input_size) * 100

    print(f"\nDone!")
    print(f"  Input:     {input_size:.1f} MB")
    print(f"  Output:    {output_size:.1f} MB")
    print(f"  Reduction: {reduction:.0f}%")
    print(f"  Classes:   {len(transformed_classes)}")
    print(f"  Enums:     {len(enriched_enums)}")
    print(f"  Mixins:    {len(mixins)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Transform api_reference.json for better LLM performance")
    parser.add_argument("input", help="Path to input api_reference.json")
    parser.add_argument("-o", "--output", default="api_reference_v2.json",
                        help="Output path (default: api_reference_v2.json)")
    args = parser.parse_args()
    transform(args.input, args.output)
